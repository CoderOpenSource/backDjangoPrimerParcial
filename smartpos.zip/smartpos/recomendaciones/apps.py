from django.apps import AppConfig


class RecomendacionesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recomendaciones'
