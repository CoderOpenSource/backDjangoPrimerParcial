# 📁 recomendaciones/urls.py
from django.urls import path
from .views import RecomendacionAprioriAPIView

urlpatterns = [
    path('apriori/', RecomendacionAprioriAPIView.as_view(), name='recomendacion-apriori'),
]
