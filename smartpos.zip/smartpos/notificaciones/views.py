from rest_framework import generics, permissions
from notificaciones.models import Notificacion
from notificaciones.serializers import NotificacionSerializer
from usuarios.utils.bitacora_utils import registrar_bitacora


class NotificacionesUsuarioView(generics.ListAPIView):
    serializer_class = NotificacionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        qs = Notificacion.objects.filter(usuario=user).order_by('-fecha_creacion')

        no_leidas = qs.filter(leido=False)
        cantidad = no_leidas.count()
        no_leidas.update(leido=True)

        registrar_bitacora(
            self.request,
            accion='Consultó sus notificaciones',
            modulo='Notificaciones',
            detalle=f"Consultó notificaciones. {cantidad} marcadas como leídas.",
            objeto_afectado='Notificacion',
            referencia_id=str(user.id)
        )

        return qs


# 🔒 Solo para administradores u otros roles permitidos
class NotificacionesAdminView(generics.ListAPIView):
    queryset = Notificacion.objects.all().order_by('-fecha_creacion')
    serializer_class = NotificacionSerializer
    permission_classes = [permissions.IsAuthenticated]  # o tu propio permiso

    def get(self, request, *args, **kwargs):
        registrar_bitacora(
            request,
            accion='Consultó todas las notificaciones del sistema',
            modulo='Notificaciones',
            detalle='Vista administrativa de todas las notificaciones.',
            objeto_afectado='Notificacion'
        )
        return super().get(request, *args, **kwargs)
